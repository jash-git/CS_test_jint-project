xcopy *.sys /s C:\ST_drivers\*.* /y
insUsbDrv.exe C:\ST_\drivers\ st.txt