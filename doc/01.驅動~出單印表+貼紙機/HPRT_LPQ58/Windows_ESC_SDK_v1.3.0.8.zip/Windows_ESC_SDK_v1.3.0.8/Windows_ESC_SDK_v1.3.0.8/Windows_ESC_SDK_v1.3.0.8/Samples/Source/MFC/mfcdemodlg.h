
//MFCDemoDlg.h : ͷ�ļ�
//

#pragma once

// CPRTMFCDemoDlg �Ի���
class CPRTMFCDemoDlg : public CDialogEx
{
private:
	
// ����
public:
	CPRTMFCDemoDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_PRTMFCDEMO_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;
	
	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();

	DECLARE_MESSAGE_MAP()
	
public:
	afx_msg void OnBnClickedPortOpen();
	afx_msg void OnBnClickedPrintReceipt();
	afx_msg void OnBnClickedStop();
	afx_msg void OnBnClickedLabel();
	afx_msg void OnBnClickedStatus();
	afx_msg void OnBnClickedOther();
	afx_msg void OnBnClickedPrintimage();
	afx_msg void OnCBNPortSelChange();
	afx_msg void OnEnChangeTxtModel();
	afx_msg void OnCBNImageSelChange();
	void SetItemsEnable(bool);
	afx_msg void OnBnClickedVersion();
	afx_msg void OnBnClickedWindowsfont();
};
